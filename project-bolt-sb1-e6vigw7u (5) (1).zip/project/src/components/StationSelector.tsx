import React from 'react';

interface StationSelectorProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const stations = [
  'Chatrapathi Shivaji Maharaj Terminus',
  'Chennai Central Railway Station',
  'Ahmedabad Junction',
  'Vijayawada Junction',
  'Secunderabad Station'
];

function StationSelector({ value, onChange }: StationSelectorProps) {
  return (
    <div className="space-y-2">
      <label htmlFor="station" className="block text-sm font-medium text-gray-700">
        Select Railway Station
      </label>
      <select
        id="station"
        value={value}
        onChange={onChange}
        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
      >
        <option value="">Select a station</option>
        {stations.map((station) => (
          <option key={station} value={station}>
            {station}
          </option>
        ))}
      </select>
    </div>
  );
}

export default StationSelector;