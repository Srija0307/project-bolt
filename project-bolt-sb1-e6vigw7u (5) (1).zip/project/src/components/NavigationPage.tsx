import React, { useState } from 'react';
import { MapPin, Volume2, AlertTriangle, Bell, Ticket } from 'lucide-react';

const locations = [
  'Public Restroom (Free)',
  'Public Waiting Hall',
  'Waiting Lounge',
  'Cafe',
  'Food Court',
  'Drinking Water',
  'Vending Machine'
];

const getRouteImage = (from: string, to: string) => {
  const routeImages: Record<string, string> = {
    'Public Restroom (Free)_Public Waiting Hall': 'https://media-hosting.imagekit.io//66e73773e3a64591/Untitled%20design%20(16).png?Expires=1837520703&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=gciiQzwFn2-112iFLM5ihkI84Rntq5rgdSQTzm51E43gC-0we8CE~zH-XSjCMuyY1Pvw6QqX-fov~DgglcC9H6n522yEgIeskumP3KdRWLYuIn2XCznQqK4~7vg8HP9FgRxNARU3S7Kop-OkyapnLiJNdwloqrRJeAjg9Sr47qu3~pSGDV0YTFv3U-XJe~5QqMmmQ8YynyUjuRgXe~el-i9y65cV5cnJuAuJtVpB7QUMsmUAi~zG~EAt4ICcFQ~2R-Jt4j2t~3MT52BAxJh~ZbZidpcHc7jb-bS-kIs2~WhOa34zWLdFJiSdAGY5G0T5REQeCWSFjWdd4sdi2UOAew__',
    'Public Restroom (Free)_Cafe': 'https://media-hosting.imagekit.io//f5c77f03749043f6/Untitled%20design%20(17).png?Expires=1837521005&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=KqUS4D3FSkJbB5tp73gqkzdLyfFUzxK~1sKWQuqDKHPIbxPnHWIaHw9yDgdFcXCV2z1yKDTqCEZvFkW8iJnWqQukni0yu~kTzO61t1TrGJEiM6kRfd~gz84txn7lrlEAhwnt3OxvicDjg2gZx7u0~JFLxinONaYdifewInribFHEKpSrKST77C3MPmCkogXorjsA-iWarjo-cGHiGosDEPz51irKGfsscBx~z40oEgdSquHntscmY3n1lK9Iy-eDDNk0FCRBsQd5jk6PljW4k~8srncsfUbDv47VgYq34zGVrb61DIUUeop5WF0IkR5XmgTp8USsvhuBNrHRLA9yLQ__',
    'Public Restroom (Free)_Food Court': 'https://media-hosting.imagekit.io//236bafb3671f4475/Untitled%20design%20(18).png?Expires=1837521523&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=dinktUSNludVXcDn3SjnkmmR1wL61NzanURM1RjW75I5V1GilVEh8ZDUCUINfykPLmeX5kDbLkOXdjM8leibhsKIFnpRqP2S98YqcsFB0hrngHOndZ39T2ficq~m458P1og1I4wnl~VPulwlTeI1~ZdQzk4waL3ptd2~sa36VUbxgbFskLEvK0nute9dWNQfOzmireq~OgzxwzE0Di3i5nt9HrzUs43krjsenyekWI0ur9peOSubbGeE2ZP0vghHyZg2GocYRnQCDRMLFgeGEoyxYjON639e11XpBB8PrtK0Of6maQ-PjUE1~r2xNfZuaDw1wTyewdOy3SbsP6mfqQ__',
    'Public Waiting Hall_Public Restroom (Free)': 'https://media-hosting.imagekit.io/c36af280d3c44b66/Untitled%20design%20(20).png?Expires=1837601774&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=lTyJnTObvjVSjK-BD9LZD5TgMWxoepsGbex0~gzjnTOmse32i1LSZ4ZXiGjumgMRnv3EmGUWSkWlcr3dx-9KcVswuUpAOD9NeUyGjZqx7aRNVOVc2s9n8X4lAOHkOXhm4WIqkxn2IbxxgzMI0L6HV8ayrYBrT6yTC-gjloqGfWIJu9-1hHWiL8PrR~OHaZa5G4lHtv9EVvFjcKymUwLZSztaPJosEyfXSrjgpioimbIOvhKUMjk-5VqG51dd7nyFsDHDvk0cbZnMCK92iFZpciN87KDXBE2cNRu~c~K~HOPuL~C0X1k3oDY2PJ6bCLcxcQOuFo8FOZ54bDfSLGGAQA__',
    'Public Waiting Hall_Cafe': 'https://media-hosting.imagekit.io/49fad44293e74c7a/Untitled%20design%20(22).png?Expires=1837602268&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=amZ~B-rn3RWKyG7Vu3szVYS5yB5xKCixw2E3fPeC3xmjfiuFfN7tx0QJ6jJ6tvLEk5cD1tDey45Trhd8wonfBL-zVKp8fTDlI66~5cK8fFCYGcAN1wC0Zr~7rlxEW19ndC0D5YKzLOp2JjQjD3D2l9OzWSWFb7m1FWDF7O8T65MHpOXafiNJZ-THErSKUZ6qO3hcmlo80m74vdSOQHKdTrb593G1B9szLsyB7sDTxymtc~ugZQ6P1EMFzj0-ZfPSZvy9786S4du1fIXsfAFs29lDX2JEaa0HrxWFj6LPCD~5kb-WfDREQnagAYdMOq-AID4~dkRpF~7ceTa0-nmqqw__',
    'Public Waiting Hall_Drinking Water': 'https://media-hosting.imagekit.io//5487b65eb9d14af9/Untitled%20design%20(12).png?Expires=1835920402&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=qvMci9D7wLWxlofAXjSrtosqlkzDFuAMv4uVcN2y-RkamNoKKi5t8glvWxdS5jZXF9V5AxDPjipWbosDkl29D4UDxVcwnFKu9SpiA5pmp4lSpzKK3K7WQIfzSRXXjIQF8ZnhaEiCaHDtkV~DOeR0z2G3tmPCMcHNbfeIs6z8FPoVy6hVHMN5F2XZEJkRkg45e2Wo-N8dDBJ-cymaqo2-AXZQezRUwpsfNxKqkaEnEyyofYTD2vZ2d3fTh9IumPbzOjSAI3jvEnrod9Grl3d9xcCNefN5f1AHd0p6-vbrsZUIoosXr0EMev8HyI0axQodQfMgcJG6IQrhRdFTkcnjZg__',
    'Public Waiting Hall_Food Court': 'https://media-hosting.imagekit.io//b36cf9ad715e4f05/Untitled%20design%20(11).png?Expires=1835920316&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=XrkDWxNui-DrTw5JHjaZjxJtt8tOx46-RJwM~Go9kog92YSSSm2O-qNN5UUTtPHhe2xMPDfGeyaJ7YbjI~OIoL5kYk9B54NRnO1S3Fn6WQUbV9vQtkoS3DVChqliGZVut3rpS~ewdJk8sAL9E9cQ4c1PfvrrVhQpXX~0-13yuz~9juZSWZHIzpzOIasI6i8TlyM18JUkXAWm~k57rFQtJHRA2J-PxIclA9yt78TVHviONly4WerBNf7iGpkQ1ComYpjtU14vOFFOsLWoiTXm2MHjNXA8ZN4-UZvtllz9QlO8qhpILpNW7xQxfcyS8ORyecS1guGBMziCNVF0fknmCw__',
    'Cafe_Public Restroom (Free)': 'https://media-hosting.imagekit.io//8b202b1540794c34/Untitled%20design%20(9).png?Expires=1835919788&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=iAfeiQeYOuAqB9d7EGicGtjLNLON7Gua9TPiETv8TV8V2eKO3ykpOeYSVzOqI7G9QiPEHlbuBh5OzMdqra881OZdW3byuErlufuVL74njv9iZzf2k9ATtD5Ga9gUZtREzvmcl~Z7yv2v19ZiN-J-gLi0i942QlYwYVrUy9ec~jhZU9f0JcF63cseBkzFJxFzAC9iijp5CyzRJhBvz4O13SdkA3NyXyUbVTeumCrjR8GHdoNdgP42-0WUz-ZPbKb1Hr24YWvA5HdfBth76eRqBLjrhoiwaURyQcm-KhaYJd1ADmvyfBcojteIzX8IKxGXd4RVwthkPmmQgaG7B89hag__',
    'Cafe_Drinking Water': 'https://media-hosting.imagekit.io/40007b76c61b4e10/Untitled%20design%20(23).png?Expires=1837603856&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=LZY-I~3KkNvMVuyeR7F5cfY5Ly-QCfOo4dTQmm3yEdUeUeK05C1Pls1yZ2DqNd29u0Rb2BB6ctVF2MXzSzlu7fHCkV1hC03qhcIYLjMV-ye1khU3KVEsH8hRX9ZsYAr6sVh2a7opkGiCrZ1huJi7nPlGE6AjOmS4NC6LNV8Enh9srcLKYUWzLxvCJfQ6Ow4PHYAUVpZasMQJsMnSxdv68guvrbIc3-GUXo1AKinF2fsKxkiKRBTlRpavZ95ez28UZMssoHlTELv-qR8CX45JGV9-Yj3-D-P-VT~xjAAigpkfMmEAK~8Gkn7vhwj-W6fG-KTGAbP5HaffB7yLM8u1rw__',
    'Cafe_Food Court': 'https://media-hosting.imagekit.io/078376d65e0e4d10/Untitled%20design%20(24).png?Expires=1837604118&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=GVvc1aqamtsb7EOzixKCgjcFAuuQCbq9fQ~Fccr2x7T3SNO7ASJgcElEty~w9QPeg6ar83-Ke8XuwBYnaFXDU3lA5gRRnVGF5nbnQqnTmfFVw6qSvLPptQo3AxfrBo6ce1Jp81aVeFIa324Z9BPC~REhkah0fiFhJshZ0FJwBpYF1CIeUPcGvmxSY7DVlxjJw5PK8t4frTplLkVQ71w0y3ISDHKbhrHJd5GMjjJxOrVep5L~cikqU2oegRl1H4AU8N4sdDrbSOZvm4-mxNGCTN-bL1r3VfETdyhQQViJ~1AXlNy8Tk2JXIzVFvCnk0duQ8l0WuYSSl57ESswavEQKA__',
    'Cafe_Vending Machine': 'https://media-hosting.imagekit.io/fa6bbf56d52247e1/Untitled%20design%20(25).png?Expires=1837604310&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=a8FAVV7dY8BDDzXv0XNus-L8w8GPveDleQXa6J6XAtzxa6a83sg7ET8SoZ6dfXgUZyr97ASlD~b2gnNojpvEcfeY55XtbYURq6hQPN0qCRu0FFCppxS1JsO6aKkZvxJs6dID7Y9zXHXFNYlxfwbKWJffeFDMkPdG6ZqzMRu3iY06~6e6LE33FwUBIt3h20Uv1t6CGT85vkL4iW4i~b7E0KplfueLyaU7YmWI8GVXUbCpE00npSZeo~Dn5PJuvu87FhgFju5Pl9T4jj4ad73BCxfwWK6zPd6gFjC0PoMmziza2g2HfGvf9AmeZhdw3-rGOgtu5oi3rDYrb5QE6l9zww__',
    'Food Court_Public Restroom (Free)': 'https://media-hosting.imagekit.io/398a85a27f664069/Untitled%20design%20(26).png?Expires=1837646376&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=Xbx7Kd-Mf3YU-COTzKMS2DVsPQridnlAMOIThhgmJq1KWoPS7q6RJMOM7WVpXSgRgROLm6bzGy2SISWzj5EuIqtGKyPrLudZjQwmrAwGEdOHG7OLgrkp83S9Q3efWv38u7U8XmVVgURNd47yvGX1NjftjoMdsN6YskeHd68LG-TPse1WDje7BSuahFdrmSE1ajsKhdoEhXOsFgqvdd8OKz91~CdSvzGr3t3qijBVXTPT8JwkUfzKPhkdDCUYiQCsd3GdCech8VttPbmx1mzKCFI~9QeDBiy-rSn6kl5KBvxFDHvCLU0CF15D-uAOjua5ECEOM~LzA2F~o0EuycBsbA__',
    'Food Court_Public Waiting Hall': 'https://media-hosting.imagekit.io/72a9201e540940d3/Untitled%20design%20(27).png?Expires=1837647256&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=q0pTkcC9jtu2DXmuvoVQTTCJW5PFPe4UThTpFS98rgFMDuZFP9X57yDTgWjOXAs8QNb-4YWlO7yJd2aPrOhXbCQjAiaPs-sybx5cHgxiSo6LB9GfFV0CWTQadYfrDg44AGNrRM68uEI99YNjUR8xpojcWR-7gTsysO0MK6598586xDZAs7aIWP2Lyc8XPqMCocv4zquAv3xvgUlKGddmZWk0c-UPw0v676thu3-1v2yGSs5Fu5-zGtU73r8Q491XsZD9Obd1M58eXlaejewy7PBdeCUAqETjc0Hf~xEiqKoF4Ce99x3pp2SfUj9NVBCl9ushcfny0NIq3kmhzvJCDA__',
    'Food Court_Cafe': 'https://media-hosting.imagekit.io/2cf3b8bf25b74d8b/Untitled%20design%20(28).png?Expires=1837647707&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=fc8U0UO8NaWGMxNizQDVE73o786j3YvkbLmS7nGx2REU9Qqxl-Zs2y~CFs9vI4bK0~2~YiwzZkhVwBe8QYmRljsRHVedt9-0H-dZCCYUEBs-w70A9Hk00sXzr8CFKunnOhvVdtnVEDROOmtVvhtE7suIl8lymoA3p0OdE4Hw7XZO9QZH-PyIlIizaJQnP-0NDVD4vAUBwFmHEM529p~H-Qpc7SwLOqucOtZqiER-~zRu87bVnczMUb3AsSxRAURsjgaM312XxAsnb9RZLkp1bUbS1vYh9KbKj~Yvs1V1lZELBFlQnoI5MQRbyPOBOvc67Mb85DH95J5IaABjdkZxOA__',
    'Food Court_Vending Machine': 'https://media-hosting.imagekit.io/610c505f1e514aa0/Untitled%20design%20(29).png?Expires=1837647917&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=XrW9h11Xz101~46yiiux9~wlrPuUZciCYxReaUw4ossaeMQeM~ARtW6LEcSg9xx8RZxxK0skdpWNAxUAYvoywLzLJE-JVW0bj5i4WUPCUUkHRezub~wa1k1k3QvQyjgof2trV0182guvIfbSTdizgNcq-49qzeQ8te4loRhgQWXI2ptSamUTLWp2sYVosRe8gqjkHL8lZFdbFPi5gTRbnjm1KjHXARLxZiSJGk6I4E6G0oh0OfIRKGuwcRxqySdgO2W35t0Ar-fRr2QNZJEe3IJicZxig7W~wX4Wy2pOmevNd7yLOX~NiULXnxY6tgm4-zTV5XJ7Cx5p37oEiE2aJQ__'
  };

  const routeKey = `${from}_${to}`;
  return routeImages[routeKey] || "https://media-hosting.imagekit.io//4c51bceba3474fe7/Untitled%20design.jpg?Expires=1837226165&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=uIe4v9Vpp2N7i-kPeAgpS14TYEVDdsVJuelhUR-gnhfUZyXln440iCi4xzQEk4iIJwLnvxBP6caothP6LLhW68tfKPaRGHu6RpiMQQBIOZbhY5iorW1uxRGsUJHrjC20HsnLqNBuHm2NuDw2OWTA0hK3eeI7BF8tkkoboF4FwOXlQ6QpQTptiEMLFJEQfOHKSwaBO5lZzyNX~KFp8Aa4SnLLD7MT0Nbf~WHYbi1HHq2hWRzrvUVH9nLU8dScJnEVGGioRHcTpisDGi~PhJfI2cFNJpk94NUnZYLMcOK~n544FVunTp3aRnPq6bDxJIN16ziGx1HHRh1Y~KFbrbBmhA__";
};

const getCustomDirections = (from: string, to: string) => {
  const directions: Record<string, string> = {
    'Public Restroom (Free)_Public Waiting Hall': 'Face towards noth direction and go towards your left for 100 meters and use foot over bridge and land on platform 2',
    'Public Restroom (Free)_Cafe': 'Face towards north direction and go 50 meters towards your left side',
    'Public Restroom (Free)_Food Court': 'Face towards noth direction and walk towards your left for 100 meters and use foot over bridge and land on platform 1 and walk for 50 meters',
    'Public Waiting Hall_Public Restroom (Free)': 'face north direction and walks for 100 meters there you find public toilets on your left and after walking further for 50 meters',
    'Public Waiting Hall_Cafe': 'use footover bridge and land on platform 2 and go towards east direction for 150 meters',
    'Public Waiting Hall_Drinking Water': 'use foor over bridge and land on platform 1 and go further 75 meters towards east direction',
    'Public Waiting Hall_Food Court': 'use foor over bridge and land on platform 1 and go further 100 meters towards east direction',
    'Cafe_Public Restroom (Free)': 'walk past the cafe 50 meters.',
    'Cafe_Drinking Water': 'use foot over bridge and land on platform 1 and walk towards west direction for 75 meters',
    'Cafe_Food Court': 'use foot over bridge and land on platform 1 and walk towards west direction for 50 meters',
    'Cafe_Vending Machine': 'use foot over bridge and land on platform 1 and walk towards west direction for 125 meters',
    'Food Court_Public Restroom (Free)': 'face towards north direction and go towards your right for 75 meters',
    'Food Court_Public Waiting Hall': 'Face Railway track and turn right and within 20 meters you can find public waiting hall',
    'Food Court_Cafe': 'Use foot over bridge and land on platform 3 and walk for 30 meters towards west direction',
    'Food Court_Vending Machine': 'Walk towards west direction for 50 meters'
  };

  const routeKey = `${from}_${to}`;
  return directions[routeKey] || `Starting from ${from}, walk straight for 50 meters, turn right at the main concourse, continue for 30 meters to reach ${to}.`;
};

const alerts = [
  {
    type: 'urgent',
    message: 'Platform 3 under maintenance. Please use alternative routes.',
    timestamp: '10 mins ago'
  },
  {
    type: 'info',
    message: 'New food stall opened near Platform 2 waiting area',
    timestamp: '1 hour ago'
  },
  {
    type: 'warning',
    message: 'Elevator near Platform 1 temporarily out of service',
    timestamp: '2 hours ago'
  }
];

const ticketCounters = [
  { id: 1, status: 'Open', waitTime: '5-10 mins', type: 'General' },
  { id: 2, status: 'Open', waitTime: '15-20 mins', type: 'Senior Citizen/Disabled' },
  { id: 3, status: 'Closed', waitTime: '-', type: 'Premium' },
];

function NavigationPage() {
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  
  const handleVoiceGuidance = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(getCustomDirections(fromLocation, toLocation));
      window.speechSynthesis.speak(utterance);
    }
  };

  const layoutImage = getRouteImage(fromLocation, toLocation);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-blue-700 text-white py-4 shadow-lg">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold">Secunderabad Station</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column - Controls */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-md space-y-6">
              {/* Location Controls */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Current Location
                  </label>
                  <select
                    value={fromLocation}
                    onChange={(e) => setFromLocation(e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                  >
                    <option value="">Select your location</option>
                    {locations.map((loc) => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Destination
                  </label>
                  <select
                    value={toLocation}
                    onChange={(e) => setToLocation(e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                  >
                    <option value="">Select your destination</option>
                    {locations.filter(loc => loc !== fromLocation).map((loc) => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Ticket Counter Status */}
              <div className="border-t pt-6">
                <div className="flex items-center gap-2 mb-4">
                  <Ticket className="h-5 w-5 text-blue-600" />
                  <h3 className="font-semibold">Ticket Counter Status</h3>
                </div>
                <div className="space-y-3">
                  {ticketCounters.map((counter) => (
                    <div key={counter.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">Counter {counter.id}</p>
                        <p className="text-sm text-gray-600">{counter.type}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-medium ${counter.status === 'Open' ? 'text-green-600' : 'text-red-600'}`}>
                          {counter.status}
                        </p>
                        <p className="text-sm text-gray-600">Wait: {counter.waitTime}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {fromLocation && toLocation && (
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-blue-600"  />
                  Directions
                </h3>
                <p className="text-gray-600 mb-4">{getCustomDirections(fromLocation, toLocation)}</p>
                <button
                  onClick={handleVoiceGuidance}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors w-full justify-center"
                >
                  <Volume2 className="h-5 w-5" />
                  Voice Guidance
                </button>
              </div>
            )}
          </div>

          {/* Right Column - Map and Alerts */}
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="relative aspect-[16/9] overflow-hidden rounded-lg">
                <img
                  src={layoutImage}
                  alt={`Route from ${fromLocation} to ${toLocation}`}
                  className="w-full h-full object-cover transition-opacity duration-300"
                />
              </div>
              <p className="text-sm text-gray-500 mt-3">
                {fromLocation && toLocation 
                  ? `Route: ${fromLocation} → ${toLocation}`
                  : "Station Layout Map"}
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center gap-2 mb-4">
                <Bell className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold">Railway Alerts</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {alerts.map((alert, index) => (
                  <div 
                    key={index} 
                    className={`p-4 rounded-lg flex items-start gap-3 ${
                      alert.type === 'urgent' 
                        ? 'bg-red-50 text-red-700' 
                        : alert.type === 'warning'
                        ? 'bg-yellow-50 text-yellow-700'
                        : 'bg-blue-50 text-blue-700'
                    }`}
                  >
                    <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs opacity-75 mt-1">{alert.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default NavigationPage;