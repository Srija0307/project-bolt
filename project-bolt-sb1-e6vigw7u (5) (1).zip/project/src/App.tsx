import React from 'react';
import { useState } from 'react';
import { Train, Navigation2, Volume2 } from 'lucide-react';
import StationSelector from './components/StationSelector';
import NavigationPage from './components/NavigationPage';

function App() {
  const [selectedStation, setSelectedStation] = useState('');
  const [showNavigation, setShowNavigation] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedStation) {
      setShowNavigation(true);
    }
  };

  if (showNavigation && selectedStation === 'Secunderabad Station') {
    return <NavigationPage />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-blue-700 text-white py-4 shadow-lg">
        <div className="container mx-auto px-4 flex items-center gap-2">
          <Train className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Railway-Nav System</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <StationSelector
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
            />
            
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              disabled={!selectedStation}
            >
              <Navigation2 className="h-5 w-5" />
              Submit
            </button>
          </form>

          <div className="mt-8 pt-8 border-t">
            <h2 className="text-xl font-semibold mb-4">Contact Information</h2>
            <div className="text-gray-600">
              <p>Railway Navigation Support</p>
              <p>Email: support@railway-nav.com</p>
              <p>Phone: 1800-XXX-XXXX</p>
              <p>Available 24/7</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;